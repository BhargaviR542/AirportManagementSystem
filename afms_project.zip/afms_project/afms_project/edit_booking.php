<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

// Security: Admin Only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); exit;
}

$id = $_GET['id'] ?? null;
if (!$id) { header("Location: booking.php"); exit; }

// HANDLE FORM SUBMISSION
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_flight = $_POST['flight_id'];
    $new_seat = $_POST['seat_number'];
    $new_name = $_POST['guest_name'];
    $booking_id = $_POST['booking_id'];

    // CHECK IF SEAT IS TAKEN (excluding current booking)
    $stmt = $conn->prepare("
        SELECT COUNT(*) FROM bookings 
        WHERE flight_id = ? AND seat_number = ? AND booking_id != ?
    ");
    $stmt->execute([$new_flight, $new_seat, $booking_id]);
    
    if ($stmt->fetchColumn() > 0) {
        $error = "Seat $new_seat is already taken on that flight!";
    } else {
        // UPDATE BOOKING
        $update = $conn->prepare("
            UPDATE bookings 
            SET flight_id = ?, seat_number = ?, guest_name = ? 
            WHERE booking_id = ?
        ");
        $update->execute([$new_flight, $new_seat, $new_name, $booking_id]);
        echo "<script>alert('Booking Updated Successfully'); window.location='booking.php';</script>";
        exit;
    }
}

// FETCH CURRENT BOOKING DETAILS
$stmt = $conn->prepare("SELECT * FROM bookings WHERE booking_id = ?");
$stmt->execute([$id]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);

// FETCH ALL FLIGHTS (For dropdown)
$flights = $conn->query("SELECT * FROM flights ORDER BY departure_time ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Edit Booking</title>
        <style>
        body {
            font-family: sans-serif;
            background: #eee;
            padding: 20px;
            display: flex;
            justify-content: center;
        }

        .form-box {
            background: white;
            padding: 30px;
            border-radius: 8px;
            width: 400px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        input,
        select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 4px;
        }

        .error {
            color: red;
            margin-bottom: 10px;
            text-align: center;
        }
        </style>
    </head>

    <body>

        <div class="form-box">
            <h3 style="text-align:center;">Edit Booking #<?= $booking['booking_id'] ?></h3>

            <?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>

            <form method="POST">
                <input type="hidden" name="booking_id" value="<?= $booking['booking_id'] ?>">

                <label>Passenger Name:</label>
                <input type="text" name="guest_name" value="<?= htmlspecialchars($booking['guest_name']) ?>" required>

                <label>Select Flight:</label>
                <select name="flight_id" required>
                    <?php foreach($flights as $f): ?>
                    <option value="<?= $f['flight_id'] ?>"
                        <?= $f['flight_id'] == $booking['flight_id'] ? 'selected' : '' ?>>
                        <?= $f['flight_number'] ?> (<?= $f['origin'] ?> -> <?= $f['destination'] ?>)
                    </option>
                    <?php endforeach; ?>
                </select>

                <label>Seat Number (e.g. 1A, 2B):</label>
                <input type="text" name="seat_number" value="<?= htmlspecialchars($booking['seat_number']) ?>" required
                    pattern="[1-6][A-D]" title="Rows 1-6, Seats A-D (e.g., 1A)">

                <button type="submit">Update Booking</button>
                <a href="booking.php"
                    style="display:block; text-align:center; margin-top:15px; color:#555; text-decoration:none;">Cancel</a>
            </form>
        </div>

    </body>

</html>