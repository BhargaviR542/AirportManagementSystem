<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

if (!empty($_POST['email'])) {
    $email = trim($_POST['email']);
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
    $stmt->execute([':email' => $email]);
    echo $stmt->fetch(PDO::FETCH_ASSOC) ? 'exists' : 'available';
    exit;
}

if (!empty($_POST['username'])) {
    $username = trim($_POST['username']);
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute([':username' => $username]);
    echo $stmt->fetch(PDO::FETCH_ASSOC) ? 'exists' : 'available';
    exit;
}

echo 'invalid';

?>