<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

// 1. SECURITY CHECK
if (!isset($_SESSION['role'])) {
    header("Location: login.php"); exit;
}

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'] ?? 0;

// 2. FETCH BOOKINGS (Same logic as before)
if ($role === 'admin') {
    $sql = "SELECT b.booking_id, b.guest_name, b.seat_number, b.booking_time, 
                   f.flight_number, f.origin, f.destination, f.departure_time,
                   u.username as booked_by
            FROM bookings b
            JOIN flights f ON b.flight_id = f.flight_id
            LEFT JOIN users u ON b.user_id = u.user_id
            ORDER BY b.booking_time DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
} else {
    $sql = "SELECT b.booking_id, b.guest_name, b.seat_number, b.booking_time, 
                   f.flight_number, f.origin, f.destination, f.departure_time
            FROM bookings b
            JOIN flights f ON b.flight_id = f.flight_id
            WHERE b.user_id = ?
            ORDER BY b.booking_time DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$user_id]);
}
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>My Bookings</title>
        <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }

        .container {
            max-width: 1100px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .btn-back {
            background: #6c757d;
            color: white;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 4px;
        }

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            white-space: nowrap;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        /* Button Styles */
        .btn-cancel {
            color: red;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.2em;
        }

        .btn-edit {
            color: blue;
            text-decoration: none;
            font-weight: bold;
            font-size: 1.2em;
            margin-right: 10px;
        }

        .msg-locked {
            color: #999;
            font-style: italic;
            font-size: 0.9em;
        }
        </style>
    </head>

    <body>

        <div class="container">
            <div class="header-actions">
                <a href="<?= $role === 'admin' ? 'admin.php' : 'passenger.php' ?>" class="btn-back">&larr; Back to
                    Dashboard</a>
                <div style="font-weight:bold; color:#555;">Logged in as:
                    <?= htmlspecialchars(strtoupper($_SESSION['username'] ?? 'Guest')) ?></div>
            </div>

            <h2><?= $role === 'admin' ? 'All Bookings' : 'My Trip History' ?></h2>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Ref</th>
                            <th>Flight</th>
                            <th>Route</th>
                            <th>Date</th>
                            <th>Passenger</th>
                            <th>Seat</th>
                            <?php if($role === 'admin'): ?><th>Booked By</th><?php endif; ?>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($bookings) > 0): ?>
                        <?php foreach ($bookings as $b): 
                        // --- TIME CALCULATION ---
                        $flight_time = strtotime($b['departure_time']); // Flight Timestamp
                        $current_time = time(); // Current Timestamp
                        
                        // Calculate difference in hours
                        $hours_until_flight = ($flight_time - $current_time) / 3600; 

                        // Rule: Can cancel if more than 24 hours remain OR if user is Admin
                        $can_cancel = ($hours_until_flight > 24) || ($role === 'admin');
                    ?>
                        <tr>
                            <td style="font-weight:bold;">#<?= $b['booking_id'] ?></td>
                            <td style="color:#007bff;"><?= htmlspecialchars($b['flight_number']) ?></td>
                            <td><?= htmlspecialchars($b['origin']) ?> &rarr; <?= htmlspecialchars($b['destination']) ?>
                            </td>
                            <td><?= date('M d, H:i', $flight_time) ?></td>
                            <td><?= htmlspecialchars($b['guest_name']) ?></td>
                            <td style="color:green; font-weight:bold;"><?= htmlspecialchars($b['seat_number']) ?></td>

                            <?php if($role === 'admin'): ?>
                            <td style="font-size:0.9em;"><?= htmlspecialchars($b['booked_by'] ?? 'Guest') ?></td>
                            <?php endif; ?>

                            <td>
                                <?php if ($role === 'admin'): ?>
                                <a href="edit_booking.php?id=<?= $b['booking_id'] ?>" class="btn-edit"
                                    title="Edit">✏️</a>
                                <?php endif; ?>

                                <?php if ($can_cancel): ?>
                                <a href="cancel_booking.php?id=<?= $b['booking_id'] ?>" class="btn-cancel"
                                    onclick="return confirm('Are you sure? Refund policies apply.');"
                                    title="Cancel Booking">❌</a>
                                <?php else: ?>
                                <span class="msg-locked" title="Less than 24h to departure">Non-Refundable</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="8" style="padding:20px;">No bookings found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>

</html>