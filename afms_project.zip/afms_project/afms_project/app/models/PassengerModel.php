<?php
// app/models/PassengerModel.php
class PassengerModel {
    private $db;
    
    public function __construct($database) { 
        $this->db = $database; 
    }

    // Check if username or email exists
    public function checkUserExists($username, $email) {
        try {
            if (!empty($username)) {
                $stmt = $this->db->prepare("SELECT id FROM users WHERE username = :username LIMIT 1");
                $stmt->execute([':username' => $username]);
            } elseif (!empty($email)) {
                $stmt = $this->db->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
                $stmt->execute([':email' => $email]);
            } else {
                return false;
            }
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return false;
        }
    }

    // Add passenger and return ID
    public function addPassenger($fullname, $email, $username, $hashedPassword) {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO users (full_name, email, username, password, role) 
                 VALUES (:fullname, :email, :username, :password, 'passenger')"
            );
            $stmt->execute([
                ':fullname'=>$fullname,
                ':email'=>$email,
                ':username'=>$username,
                ':password'=>$hashedPassword
            ]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            throw new Exception("Database Error: Could not register user.");
        }
    }

    // Set cookie and store in DB (SECURITY IMPROVED)
    public function setCookieInDatabase($userId, $name, $value, $expire = 86400) {
        try {
            $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;

            setcookie($name, $value, [
                'expires' => time() + $expire,
                'path' => '/',
                'secure' => $secure,
                'httponly' => true,
                'samesite' => 'Lax'
            ]);

            $stmt = $this->db->prepare(
                "INSERT INTO user_cookies (user_id, cookie_name, cookie_value)
                 VALUES (:user_id, :cookie_name, :cookie_value)
                 ON DUPLICATE KEY UPDATE cookie_value = :cookie_value"
            );
            $stmt->execute([
                ':user_id'=>$userId,
                ':cookie_name'=>$name,
                ':cookie_value'=>$value
            ]);
        } catch (PDOException $e) {
            // Don't stop registration if cookie DB insert fails
        }
    }
}
?>
