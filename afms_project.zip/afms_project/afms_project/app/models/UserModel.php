<?php
// app/models/UserModel.php
class UserModel {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    // Fetch user by username and role
    public function getUser($username, $role) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username AND role = :role");
        $stmt->execute([':username' => $username, ':role' => $role]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Set visitor cookie and store in DB
    public function setCookieInDatabase($userId, $name, $value, $expire = 86400) {
        setcookie($name, $value, time() + $expire, "/");
        $stmt = $this->db->prepare(
            "INSERT INTO user_cookies (user_id, cookie_name, cookie_value)
             VALUES (:user_id, :cookie_name, :cookie_value)
             ON DUPLICATE KEY UPDATE cookie_value = :cookie_value"
        );
        $stmt->execute([
            ':user_id' => $userId,
            ':cookie_name' => $name,
            ':cookie_value' => $value
        ]);
    }
}
?>
