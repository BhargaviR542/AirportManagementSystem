<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Passenger Registration</title>
        <link rel="stylesheet" href="assets/styles/style.css">
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <style>
        .error { color: red; }
        .success { color: green; }
        label { cursor: pointer; }
        </style>
    </head>

    <body>
        <div class="register-container">
            <h2>Passenger Registration</h2>

            <?php
            if(!empty($_SESSION['error'])) { echo "<p class='error'>".$_SESSION['error']."</p>"; unset($_SESSION['error']); }
            if(!empty($_SESSION['success'])) { echo "<p class='success'>".$_SESSION['success']."</p>"; unset($_SESSION['success']); }
            ?>

            <form method="POST" id="registerForm" novalidate>
                <div class="form-row">
                    <label for="fullname">Full Name:</label>
                    <input type="text" name="fullname" id="fullname" required>
                </div>
                <div class="form-row">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" required>
                    <small id="emailMsg"></small>
                </div>
                <div class="form-row">
                    <label for="username">Username:</label>
                    <input type="text" name="username" id="username" required>
                    <small id="userMsg"></small>
                </div>
                <div class="form-row">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <div class="form-row">
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" name="confirm_password" id="confirm_password" required>
                </div>
                <button type="submit" id="submitBtn" disabled>Register</button>
                <p class="note">Already have an account? <a href="index.php?page=login">Login</a></p>
            </form>
        </div>

        <script>
        $(document).ready(function() {
            let emailValid = false,
                usernameValid = false;

            const currentPageUrl = window.location.href.split('?')[0];
            const ajaxUrl = currentPageUrl + '?action=ajaxCheck';

            function updateSubmit() {
                $('#submitBtn').prop('disabled', !(emailValid && usernameValid));
            }

            function validateEmailFormat(email) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailRegex.test(email) && email.endsWith('@gmail.com');
            }

            $('#email').on('change blur', function() {
                const email = $(this).val().trim();
                if (!email) {
                    emailValid = false;
                    $('#emailMsg').text('');
                    updateSubmit();
                    return;
                }

                if (!validateEmailFormat(email)) {
                    $('#emailMsg').text('Enter valid Email').css('color', 'red');
                    emailValid = false;
                    updateSubmit();
                    return;
                }

                $.post(ajaxUrl, {
                    email: email
                }, function(res) {
                    res = res.trim();
                    if (res === 'exists') {
                        $('#emailMsg').text('Email already exists').css('color', 'red');
                        emailValid = false;
                    } else if (res === 'invalid_format') {
                        $('#emailMsg').text('Email must be a valid @gmail.com address').css('color', 'red');
                        emailValid = false;
                    } else {
                        $('#emailMsg').text('Email available').css('color', 'green');
                        emailValid = true;
                    }
                    updateSubmit();
                });
            });

            $('#username').on('change blur', function() {
                const username = $(this).val().trim();
                if (!username) {
                    usernameValid = false;
                    $('#userMsg').text('');
                    updateSubmit();
                    return;
                }
                $.post(ajaxUrl, {
                    username: username
                }, function(res) {
                    res = res.trim();
                    if (res === 'exists') {
                        $('#userMsg').text('Username taken').css('color', 'red');
                        usernameValid = false;
                    } else {
                        $('#userMsg').text('Username available').css('color', 'green');
                        usernameValid = true;
                    }
                    updateSubmit();
                });
            });

            $('#registerForm').on('submit', function(e) {
                $('#email').trigger('blur');
                $('#username').trigger('blur');

                if (!emailValid || !usernameValid) {
                    e.preventDefault();
                }
            });

            if ($('#email').val()) $('#email').trigger('blur');
            if ($('#username').val()) $('#username').trigger('blur');
            updateSubmit();
        });
        </script>
    </body>

</html>
