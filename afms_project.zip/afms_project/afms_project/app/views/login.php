<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>AFMS Login</title>
        <link rel="stylesheet" href="assets/styles/style.css">
    </head>

    <body>
        <div class="login-container">
            <h2>Airport Flight Management System</h2>

            <?php if (!empty($_SESSION['error'])): ?>
            <p class="error"><?= htmlspecialchars($_SESSION['error']) ?></p>
            <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <?php if (!empty($_SESSION['success'])): ?>
            <p class="success"><?= htmlspecialchars($_SESSION['success']) ?></p>
            <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <form method="POST" novalidate>
                <div class="form-row">
                    <label>Role:</label>
                    <select name="role" required>
                        <option value="">-- Select Role --</option>
                        <option value="admin"
                            <?= (isset($_SESSION['old']['role']) && $_SESSION['old']['role']=='admin') ? 'selected' : '' ?>>
                            Admin</option>
                        <option value="passenger"
                            <?= (isset($_SESSION['old']['role']) && $_SESSION['old']['role']=='passenger') ? 'selected' : '' ?>>
                            Passenger</option>
                    </select>
                </div>

                <div class="form-row">
                    <label>Username:</label>
                    <input type="text" name="username" placeholder="Enter username" required
                        value="<?= isset($_SESSION['old']['username']) ? htmlspecialchars($_SESSION['old']['username']) : '' ?>">
                </div>

                <div class="form-row">
                    <label>Password:</label>
                    <input type="password" name="password" placeholder="Enter password" required>
                </div>

                <button type="submit">Login</button>
                <p class="note">Don't have an account? <a href="index.php?page=register">Register here</a></p>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="index.php?page=login&action=guest" class="guest-link">Continue as Guest</a>
                </div>
            </form>

            <?php unset($_SESSION['old']); ?>
        </div>
    </body>

</html>
