<?php
// app/controllers/PassengerController.php
class PassengerController {
    private $model;
    
    public function __construct($model) { 
        $this->model = $model; 
    }

    public function handleAjaxCheck() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        header('Content-Type: text/plain');

        if (isset($_POST['email'])) {
            $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);

            if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !str_ends_with($email, '@gmail.com')) {
                echo 'invalid_format';
                exit;
            }

            $exists = $this->model->checkUserExists('', $email);
            echo $exists ? 'exists' : 'available';
            exit;
        }

        if (isset($_POST['username'])) {
            $username = htmlspecialchars(trim($_POST['username']));
            $exists = $this->model->checkUserExists($username, '');
            echo $exists ? 'exists' : 'available';
            exit;
        }
    }

    public function handleRegister() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        $fullname = htmlspecialchars(trim($_POST['fullname']));
        $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
        $username = htmlspecialchars(trim($_POST['username']));
        $password = trim($_POST['password']);
        $confirm = trim($_POST['confirm_password']);

        if (!$fullname || !$email || !$username || !$password || !$confirm) {
            $_SESSION['error'] = "Please fill all fields.";
            header("Location: index.php?page=register"); exit;
        }
        if ($password !== $confirm) {
            $_SESSION['error'] = "Passwords do not match.";
            header("Location: index.php?page=register"); exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !str_ends_with($email, '@gmail.com')) {
            $_SESSION['error'] = "Enter valid Email address.";
            header("Location: index.php?page=register"); exit;
        }

        if ($this->model->checkUserExists('', $email)) {
            $_SESSION['error'] = "Email already exists!";
            header("Location: index.php?page=register"); exit;
        }
        if ($this->model->checkUserExists($username, '')) {
            $_SESSION['error'] = "Username already exists!";
            header("Location: index.php?page=register"); exit;
        }

        try {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $userId = $this->model->addPassenger($fullname, $email, $username, $hashed);

            $_SESSION['user_id'] = $userId;
            $_SESSION['status'] = 'Logged_in';

            $visitorId = bin2hex(random_bytes(16));
            $this->model->setCookieInDatabase($userId, 'visitor_id', $visitorId, 60*60*24*365);

            $_SESSION['success'] = "Registration successful!";
            header("Location: index.php?page=register");
            exit;

        } catch (Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header("Location: index.php?page=register"); exit;
        }
    }
}
?>
