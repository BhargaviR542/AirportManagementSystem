<?php
// app/controllers/LoginController.php
class LoginController {
    private $userModel;

    public function __construct($userModel) {
        $this->userModel = $userModel;
    }

    public function handleLogin() {
        // Handle guest login
        if (isset($_GET['action']) && $_GET['action'] === 'guest') {
            $_SESSION['role'] = 'guest';
            $_SESSION['username'] = 'Guest';
            $_SESSION['status'] = 'Logged_in';
            header("Location: index.php?page=passenger");
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim(filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING));
            $password = trim(filter_input(INPUT_POST, 'password', FILTER_UNSAFE_RAW));
            $role     = trim(filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING));

            $_SESSION['old'] = ['username'=>$username, 'role'=>$role];

            if (empty($username) || empty($password) || empty($role)) {
                $_SESSION['error'] = "Please fill all fields and select a role.";
                header("Location: index.php?page=login"); exit;
            }

            $user = $this->userModel->getUser($username, $role);

            if (!$user || !password_verify($password, $user['password'])) {
                $_SESSION['error'] = "Invalid username or password.";
                header("Location: index.php?page=login"); exit;
            }

            $_SESSION['user_id']  = $user['user_id']; 
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];
            $_SESSION['full_name'] = $user['full_name']; 
            $_SESSION['status']   = 'Logged_in';
            $_SESSION['success']  = "Welcome, {$user['full_name']}!";

            if (!isset($_COOKIE['visitor_id'])) {
                $visitorId = bin2hex(random_bytes(16));
                $this->userModel->setCookieInDatabase($user['user_id'], 'visitor_id', $visitorId, 60*60*24*365);
            }

            $pageViews = isset($_COOKIE['page_view_count']) ? (int)$_COOKIE['page_view_count'] + 1 : 1;
            setcookie('page_view_count', $pageViews, time()+60*60*24*30, "/");

            if ($role === 'admin') header("Location: index.php?page=admin");
            else header("Location: index.php?page=passenger");
            exit;
        }
    }
}
?>
