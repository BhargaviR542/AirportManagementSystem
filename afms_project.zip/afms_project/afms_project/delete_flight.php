<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "<p>Invalid flight ID.</p>";
    echo '<a href="admin.php">Back to Flights</a>';
    exit;
}

$id = (int)$_GET['id'];

$stmt = $conn->prepare("SELECT * FROM flights WHERE flight_id = ?");
$stmt->execute([$id]);
$flight = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$flight) {
    echo "<p>Flight not found.</p>";
    echo '<a href="admin.php">Back to Flights</a>';
    exit;
}

if (isset($_POST['confirm_delete'])) {
    $stmt = $conn->prepare("DELETE FROM flights WHERE flight_id = ?");
    $stmt->execute([$id]);

    header("Location: admin.php?message=Flight+deleted+successfully");
    exit;
}

if (isset($_POST['cancel'])) {
    header("Location: admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Delete Flight</title>
    </head>

    <body>
        <h2>Delete Flight ID <?= htmlspecialchars($flight['flight_id']) ?></h2>

        <p>Are you sure you want to delete the flight
            <strong><?= htmlspecialchars($flight['flight_number']) ?></strong>
            operated by <strong><?= htmlspecialchars($flight['airline']) ?></strong>?
        </p>

        <form method="POST">
            <button type="submit" name="confirm_delete" style="background-color:red;color:white;">Yes, Delete</button>
            <button type="submit" name="cancel">Cancel</button>
        </form>

        <a href="admin.php">Back to Flights</a>
    </body>

</html>