<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'];


$stmt = $conn->prepare("SELECT * FROM flights WHERE flight_id = ?");
$stmt->execute([$id]);
$flight = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$flight) {
    die("Flight not found!");
}

if (isset($_POST['update_flight'])) {
    $flight_number = $_POST['flight_number'];
    $airline = $_POST['airline'];
    $origin = $_POST['origin'];
    $destination = $_POST['destination'];
    $departure_time = $_POST['departure_time'];
    $arrival_time = $_POST['arrival_time'];
    $status = $_POST['status'];
    $price = $_POST['price'];

    $stmt = $conn->prepare("UPDATE flights SET flight_number=?, airline=?, origin=?, destination=?, departure_time=?, arrival_time=?, status=?, price=? WHERE flight_id=?");
    $stmt->execute([$flight_number, $airline, $origin, $destination, $departure_time, $arrival_time, $status, $price, $id]);

    header("Location: admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Edit Flight</title>
        <link rel="stylesheet" href="assets/styles/admin-style.css">
    </head>

    <body>
        <div class="container">
            <h2>Edit Flight ID <?= htmlspecialchars($flight['flight_id']) ?></h2>
            <form method="POST">
                <label>Flight Number</label>
                <input type="text" name="flight_number" value="<?= htmlspecialchars($flight['flight_number']) ?>"
                    required>

                <label>Airline</label>
                <input type="text" name="airline" value="<?= htmlspecialchars($flight['airline']) ?>" required>

                <label>From</label>
                <input type="text" name="origin" value="<?= htmlspecialchars($flight['origin']) ?>" required>

                <label>To</label>
                <input type="text" name="destination" value="<?= htmlspecialchars($flight['destination']) ?>" required>

                <label>Departure Time</label>
                <input type="datetime-local" name="departure_time"
                    value="<?= date('Y-m-d\TH:i', strtotime($flight['departure_time'])) ?>" required>

                <label>Arrival Time</label>
                <input type="datetime-local" name="arrival_time"
                    value="<?= date('Y-m-d\TH:i', strtotime($flight['arrival_time'])) ?>" required>

                <label>Status</label>
                <select name="status" required>
                    <option value="Scheduled" <?= $flight['status']=='Scheduled'?'selected':'' ?>>Scheduled</option>
                    <option value="Delayed" <?= $flight['status']=='Delayed'?'selected':'' ?>>Delayed</option>
                    <option value="Departed" <?= $flight['status']=='Departed'?'selected':'' ?>>Departed</option>
                </select>

                <label>Ticket Price ($)</label>
                <input type="number" name="price" step="0.01" min="0" value="<?= htmlspecialchars($flight['price']) ?>"
                    required>

                <button type="submit" name="update_flight">Update Flight</button>
            </form>
            <br>
            <a href="admin.php">Back to Flights</a>
        </div>
    </body>

</html>