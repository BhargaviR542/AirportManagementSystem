<?php
// Ensure connect.php establishes a PDO connection named $conn
require_once 'includes/connect.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ==================== MODEL ====================
class PassengerModel {
    private $db;
    public function __construct($database) { $this->db = $database; }

    // Check if username or email exists
    public function checkUserExists($username, $email) {
        try {
            // Use distinct checks depending on what's provided to avoid ambiguous OR conditions
            if (!empty($username)) {
                $stmt = $this->db->prepare("SELECT id FROM users WHERE username = :username LIMIT 1");
                $stmt->execute([':username' => $username]);
            } elseif (!empty($email)) {
                $stmt = $this->db->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
                $stmt->execute([':email' => $email]);
            } else {
                return false;
            }
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Log error in a real app: error_log($e->getMessage());
            return false; // Assume false on error for AJAX checks, or handle differently
        }
    }

    // Add passenger and return ID
    public function addPassenger($fullname, $email, $username, $hashedPassword) {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO users (full_name, email, username, password, role) 
                 VALUES (:fullname, :email, :username, :password, 'passenger')"
            );
            $stmt->execute([
                ':fullname'=>$fullname,
                ':email'=>$email,
                ':username'=>$username,
                ':password'=>$hashedPassword
            ]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            // Log error: error_log($e->getMessage());
            throw new Exception("Database Error: Could not register user.");
        }
    }

    // Set cookie and store in DB (SECURITY IMPROVED)
    public function setCookieInDatabase($userId, $name, $value, $expire = 86400) {
        try {
            // 1. Set the actual browser cookie SECURELY
            // Detect if running over HTTPS
            $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;

            setcookie($name, $value, [
                'expires' => time() + $expire,
                'path' => '/',
                // 'domain' => 'yourdomain.com', // Uncomment and set for production
                'secure' => $secure,     // Only send over HTTPS if available
                'httponly' => true,      // CRITICAL: Prevent JS access (XSS protection)
                'samesite' => 'Lax'      // CSRF protection
            ]);

            // 2. Store cookie record in DB
            $stmt = $this->db->prepare(
                "INSERT INTO user_cookies (user_id, cookie_name, cookie_value)
                 VALUES (:user_id, :cookie_name, :cookie_value)
                 ON DUPLICATE KEY UPDATE cookie_value = :cookie_value"
            );
            $stmt->execute([
                ':user_id'=>$userId,
                ':cookie_name'=>$name,
                ':cookie_value'=>$value
            ]);
        } catch (PDOException $e) {
             // Log error: error_log($e->getMessage());
             // Don't stop registration if cookie DB insert fails, but log it.
        }
    }
}

// ==================== CONTROLLER ====================
class PassengerController {
    private $model;
    public function __construct($model) { $this->model = $model; }

    // New method to handle AJAX requests internally
    public function handleAjaxCheck() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        // Turn off HTML output for AJAX response
        header('Content-Type: text/plain');

        if (isset($_POST['email'])) {
            $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);

            // --- NEW EMAIL DOMAIN VALIDATION ---
            if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !str_ends_with($email, '@gmail.com')) {
                echo 'invalid_format'; // New response for invalid format
                exit;
            }
            // --- END NEW EMAIL DOMAIN VALIDATION ---

            // Check only email
            $exists = $this->model->checkUserExists('', $email);
            echo $exists ? 'exists' : 'available';
            exit; // Stop execution here
        }

        if (isset($_POST['username'])) {
            $username = htmlspecialchars(trim($_POST['username']));
            // Check only username
            $exists = $this->model->checkUserExists($username, '');
            echo $exists ? 'exists' : 'available';
            exit; // Stop execution here
        }
    }

    public function handleRegister() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;

        $fullname = htmlspecialchars(trim($_POST['fullname']));
        $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
        $username = htmlspecialchars(trim($_POST['username']));
        $password = trim($_POST['password']);
        $confirm = trim($_POST['confirm_password']);

        if (!$fullname || !$email || !$username || !$password || !$confirm) {
            $_SESSION['error'] = "Please fill all fields.";
            header("Location: index.php?page=register"); exit;
        }
        if ($password !== $confirm) {
            $_SESSION['error'] = "Passwords do not match.";
            header("Location: index.php?page=register"); exit;
        }

        // --- NEW EMAIL DOMAIN VALIDATION (Backend) ---
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !str_ends_with($email, '@gmail.com')) {
            $_SESSION['error'] = "Enter valid Email address.";
            header("Location: index.php?page=register"); exit;
        }
        // --- END NEW EMAIL DOMAIN VALIDATION ---


        // Final backend check against DB before inserting
        // Check email explicitly
        if ($this->model->checkUserExists('', $email)) {
            $_SESSION['error'] = "Email already exists!";
             header("Location: index.php?page=register"); exit;
        }
        // Check username explicitly
        if ($this->model->checkUserExists($username, '')) {
             $_SESSION['error'] = "Username already exists!";
             header("Location: index.php?page=register"); exit;
        }

        try {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $userId = $this->model->addPassenger($fullname, $email, $username, $hashed);

            // Set session and visitor cookie
            $_SESSION['user_id'] = $userId;
            $_SESSION['status'] = 'Logged_in';

            $visitorId = bin2hex(random_bytes(16));
            $this->model->setCookieInDatabase($userId, 'visitor_id', $visitorId, 60*60*24*365);

            $_SESSION['success'] = "Registration successful!";
            header("Location: index.php?page=register");
            exit;

        } catch (Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            header("Location: " . $_SERVER['PHP_SELF']); exit;
        }
    }
}

// ==================== RUN APP ====================
$model = new PassengerModel($conn);
$controller = new PassengerController($model);

// Check if this is an AJAX request via GET parameter
if (isset($_GET['action']) && $_GET['action'] === 'ajaxCheck') {
    $controller->handleAjaxCheck();
} else {
    // Otherwise handle normal page load or form submission
    $controller->handleRegister();
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Passenger Registration</title>
        <link rel="stylesheet" href="assets/styles/style.css">
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <style>
        .error {
            color: red;
        }

        .success {
            color: green;
        }

        /* Added for accessibility improvement without changing visual style */
        label {
            cursor: pointer;
        }
        </style>
    </head>

    <body>
        <div class="register-container">
            <h2>Passenger Registration</h2>

            <?php
            if(!empty($_SESSION['error'])) { echo "<p class='error'>".$_SESSION['error']."</p>"; unset($_SESSION['error']); }
            if(!empty($_SESSION['success'])) { echo "<p class='success'>".$_SESSION['success']."</p>"; unset($_SESSION['success']); }
            ?>

            <form method="POST" id="registerForm" novalidate>
                <div class="form-row">
                    <label for="fullname">Full Name:</label>
                    <input type="text" name="fullname" id="fullname" required>
                </div>
                <div class="form-row">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" required>
                    <small id="emailMsg"></small>
                </div>
                <div class="form-row">
                    <label for="username">Username:</label>
                    <input type="text" name="username" id="username" required>
                    <small id="userMsg"></small>
                </div>
                <div class="form-row">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <div class="form-row">
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" name="confirm_password" id="confirm_password" required>
                </div>
                <button type="submit" id="submitBtn" disabled>Register</button>
                <p class="note">Already have an account? <a href="login.php">Login</a></p>
            </form>
        </div>

        <script>
        $(document).ready(function() {
            let emailValid = false,
                usernameValid = false;

            // Helper to get current page URL for AJAX
            const currentPageUrl = window.location.href.split('?')[0];
            const ajaxUrl = currentPageUrl + '?action=ajaxCheck';

            function updateSubmit() {
                $('#submitBtn').prop('disabled', !(emailValid && usernameValid));
            }

            // Function to validate @gmail.com on the frontend
            function validateEmailFormat(email) {
                // Basic email regex (can be more robust but FILTER_VALIDATE_EMAIL on backend is better)
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return emailRegex.test(email) && email.endsWith('@gmail.com');
            }

            // Changed event to 'change blur' to reduce server load (debouncing)
            $('#email').on('change blur', function() {
                const email = $(this).val().trim();
                if (!email) {
                    emailValid = false;
                    $('#emailMsg').text(''); // Clear message if empty
                    updateSubmit();
                    return;
                }

                // --- NEW FRONTEND EMAIL DOMAIN VALIDATION ---
                if (!validateEmailFormat(email)) {
                    $('#emailMsg').text('Enter valid Email').css('color', 'red');
                    emailValid = false;
                    updateSubmit();
                    return;
                }
                // --- END NEW FRONTEND EMAIL DOMAIN VALIDATION ---

                // Post to the new integrated AJAX URL for existence check
                $.post(ajaxUrl, {
                    email: email
                }, function(res) {
                    res = res.trim();
                    if (res === 'exists') {
                        $('#emailMsg').text('Email already exists').css('color', 'red');
                        emailValid = false;
                    } else if (res ===
                        'invalid_format') { // Handle backend format rejection as well
                        $('#emailMsg').text('Email must be a valid @gmail.com address').css(
                            'color', 'red');
                        emailValid = false;
                    } else {
                        $('#emailMsg').text('Email available').css('color', 'green');
                        emailValid = true;
                    }
                    updateSubmit();
                });
            });

            // Changed event to 'change blur' to reduce server load
            $('#username').on('change blur', function() {
                const username = $(this).val().trim();
                if (!username) {
                    usernameValid = false;
                    $('#userMsg').text(''); // Clear message if empty
                    updateSubmit();
                    return;
                }
                // Post to the new integrated AJAX URL
                $.post(ajaxUrl, {
                    username: username
                }, function(res) {
                    res = res.trim();
                    if (res === 'exists') {
                        $('#userMsg').text('Username taken').css('color', 'red');
                        usernameValid = false;
                    } else {
                        $('#userMsg').text('Username available').css('color', 'green');
                        usernameValid = true;
                    }
                    updateSubmit();
                });
            });

            $('#registerForm').on('submit', function(e) {
                // Trigger blur on fields to ensure all validation messages are shown
                // before final submission attempt.
                $('#email').trigger('blur');
                $('#username').trigger('blur');
                $('#password').trigger('blur'); // If you add validation for password
                $('#confirm_password').trigger('blur'); // If you add validation for confirm password

                // Check again before preventing default
                if (!emailValid || !usernameValid) {
                    e.preventDefault();
                    // Optional: alert('Please fix the errors before submitting.');
                }
            });

            // Initial check in case browser autofilled on load
            // Only trigger blur if the field has content, to avoid showing errors on empty fields initially
            if ($('#email').val()) $('#email').trigger('blur');
            if ($('#username').val()) $('#username').trigger('blur');
            updateSubmit();
        });
        </script>
    </body>

</html>