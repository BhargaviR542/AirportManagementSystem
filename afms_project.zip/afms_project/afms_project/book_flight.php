<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

if (!isset($_POST['flight_id'])) { header("Location: passenger.php"); exit; }

$flight_id = $_POST['flight_id'];
$num_passengers = $_POST['num_passengers'] ?? 1;

// [CRITICAL] Receive Data from Dashboard
$trip_type = $_POST['trip_type'] ?? 'oneway';
$final_price = $_POST['final_price'] ?? 0;

// Fetch Flight details for display
$stmt = $conn->prepare("SELECT * FROM flights WHERE flight_id = ?");
$stmt->execute([$flight_id]);
$flight = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Passenger Details</title>
        <style>
        body {
            font-family: sans-serif;
            background: #eee;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
        }

        .card {
            background: #f9f9f9;
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        input {
            width: 95%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        .badge {
            background: #17a2b8;
            color: white;
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 0.8em;
            text-transform: uppercase;
        }
        </style>
    </head>

    <body>

        <div class="container">
            <h2 style="text-align:center;">Who is flying?</h2>

            <div style="text-align:center; margin-bottom:20px; border-bottom:1px solid #eee; padding-bottom:10px;">
                <strong>Flight <?= htmlspecialchars($flight['flight_number']) ?></strong><br>
                <span class="badge"><?= htmlspecialchars($trip_type) ?></span>
                Price per person: <strong>$<?= number_format($final_price, 2) ?></strong>
            </div>

            <form action="select_seats.php" method="POST">

                <input type="hidden" name="flight_id" value="<?= $flight_id ?>">

                <input type="hidden" name="trip_type" value="<?= htmlspecialchars($trip_type) ?>">
                <input type="hidden" name="final_price" value="<?= htmlspecialchars($final_price) ?>">

                <?php for($i=1; $i <= $num_passengers; $i++): ?>
                <div class="card">
                    <h4>Passenger <?= $i ?></h4>
                    <input type="text" name="passenger_name[]" placeholder="Full Name" required>
                    <input type="text" name="passport_number[]" placeholder="Passport/ID Number" required>
                    <input type="email" name="passenger_email[]" placeholder="Email Address" required>
                </div>
                <?php endfor; ?>

                <button type="submit">Select Seats</button>
            </form>
        </div>

    </body>

</html>