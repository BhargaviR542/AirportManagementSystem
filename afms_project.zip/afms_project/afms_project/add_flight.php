<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_POST['add_flight'])) {
    $stmt = $conn->prepare("INSERT INTO flights 
        (flight_number, airline, origin, destination, departure_time, arrival_time, status, price)
        VALUES (:flight_number, :airline, :origin, :destination, :departure_time, :arrival_time, :status, :price)");

    $stmt->execute([
        ':flight_number' => $_POST['flight_number'],
        ':airline' => $_POST['airline'],
        ':origin' => $_POST['origin'],
        ':destination' => $_POST['destination'],
        ':departure_time' => $_POST['departure_time'],
        ':arrival_time' => $_POST['arrival_time'],
        ':status' => $_POST['status'],
        ':price' => $_POST['price']
    ]);

    header("Location: admin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Add Flight</title>
        <link rel="stylesheet" href="assets/styles/admin-style.css">
    </head>

    <body>
        <div class="container">
            <h2>Add Flight</h2>
            <form method="POST">
                <label>Flight Number</label>
                <input type="text" name="flight_number" required>

                <label>Airline</label>
                <input type="text" name="airline" required>

                <label>Origin</label>
                <input type="text" name="origin" required>

                <label>Destination</label>
                <input type="text" name="destination" required>

                <label>Departure Time</label>
                <input type="datetime-local" name="departure_time" required>

                <label>Arrival Time</label>
                <input type="datetime-local" name="arrival_time" required>

                <label>Status</label>
                <select name="status" required>
                    <option value="Scheduled">Scheduled</option>
                    <option value="Delayed">Delayed</option>
                    <option value="Cancelled">Cancelled</option>
                </select>

                <label>Price ($)</label>
                <input type="number" name="price" step="0.01" min="0" required>

                <button type="submit" name="add_flight">Add Flight</button>
                <a href="admin.php" style="align-items: right;">Cancel</a>

            </form>
        </div>
    </body>

</html>