<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

// 1. SECURITY CHECK
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['passenger', 'guest'])) {
    header("Location: login.php"); exit;
}

// 2. USER DATA
$role = $_SESSION['role'];
$username = $_SESSION['username'] ?? 'Guest';
$is_member = ($role === 'passenger');

// 3. GET LOCATIONS FOR DROPDOWNS
// We get unique cities to populate the "From" and "To" boxes
$locStmt = $conn->query("SELECT DISTINCT origin, destination FROM flights");
$locations = $locStmt->fetchAll(PDO::FETCH_ASSOC);

// Extract unique cities into simple arrays
$origins = array_unique(array_column($locations, 'origin'));
$destinations = array_unique(array_column($locations, 'destination'));

// 4. HANDLE SEARCH LOGIC
$flights = [];
$search_performed = false;

if (isset($_GET['search_flight'])) {
    $search_performed = true;
    $from = $_GET['origin'];
    $to = $_GET['destination'];
    $date = $_GET['date'];

    // Search Query
    $sql = "SELECT * FROM flights 
            WHERE origin = ? 
            AND destination = ? 
            AND DATE(departure_time) = ? 
            AND departure_time > NOW() 
            ORDER BY departure_time ASC";
            
    $stmt = $conn->prepare($sql);
    $stmt->execute([$from, $to, $date]);
    $flights = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Search Flights</title>
        <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }

        .dashboard {
            max-width: 1100px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* HEADER */
        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }

        .user-info h2 {
            margin: 0;
            font-size: 24px;
            color: #333;
        }

        .member-badge {
            background: #ffc107;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            color: #333;
            vertical-align: middle;
            margin-left: 8px;
        }

        .header-actions {
            display: flex;
            gap: 10px;
        }

        .btn-logout {
            text-decoration: none;
            background: #dc3545;
            color: white;
            padding: 8px 15px;
            border-radius: 4px;
            font-size: 14px;
            font-weight: bold;
        }

        .btn-history {
            text-decoration: none;
            background: #007bff;
            color: white;
            padding: 8px 15px;
            border-radius: 4px;
            font-size: 14px;
            font-weight: bold;
        }

        .btn-help {
            text-decoration: none;
            background: #6c757d;
            color: white;
            padding: 8px 15px;
            border-radius: 4px;
            font-size: 14px;
            font-weight: bold;
        }

        /* SEARCH BAR STYLES */
        .search-box {
            background: #e9ecef;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            border: 1px solid #dee2e6;
        }

        .search-form {
            display: flex;
            gap: 15px;
            align-items: flex-end;
            justify-content: center;
            flex-wrap: wrap;
        }

        .form-group {
            text-align: left;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
            font-size: 14px;
        }

        .form-group select,
        .form-group input {
            padding: 10px;
            width: 200px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .btn-search {
            padding: 10px 25px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            height: 38px;
        }

        .btn-search:hover {
            background: #0056b3;
        }

        /* TRIP TOGGLE (Hidden until search is done) */
        .controls-panel {
            background: #fff3cd;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
            border: 1px solid #ffeeba;
            display: inline-block;
        }

        .trip-toggle label {
            margin: 0 15px;
            cursor: pointer;
            font-weight: bold;
            font-size: 16px;
            color: #856404;
        }

        .trip-toggle input {
            margin-right: 5px;
            transform: scale(1.2);
        }

        /* TABLE */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            vertical-align: top;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        .btn-book {
            background: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }

        .price-tag {
            font-weight: bold;
            color: green;
            font-size: 1.2em;
        }

        .time-box {
            text-align: left;
            padding-left: 10px;
        }

        .date-main {
            font-weight: bold;
            color: #333;
            display: block;
        }

        .return-info {
            display: none;
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px dashed #ccc;
            color: #0056b3;
        }

        .return-label {
            font-size: 0.8em;
            text-transform: uppercase;
            font-weight: bold;
            color: #0056b3;
        }

        .no-results {
            text-align: center;
            padding: 40px;
            color: #777;
            font-size: 1.2em;
        }
        </style>

        <script>
        function updateAllPrices() {
            var isRoundTrip = document.getElementById('mode_round').checked;
            var tripTypeVal = isRoundTrip ? 'roundtrip' : 'oneway';

            var priceSpans = document.querySelectorAll('.dynamic-price');
            priceSpans.forEach(function(span) {
                var flightId = span.getAttribute('data-id');
                var basePrice = parseFloat(span.getAttribute('data-base'));
                var finalPrice = isRoundTrip ? (basePrice * 2) : basePrice;

                span.innerText = "$" + finalPrice.toFixed(2);
                document.getElementById('input-price-' + flightId).value = finalPrice.toFixed(2);
                document.getElementById('input-type-' + flightId).value = tripTypeVal;
            });

            var returnDivs = document.querySelectorAll('.return-info');
            returnDivs.forEach(function(div) {
                div.style.display = isRoundTrip ? 'block' : 'none';
            });
        }
        </script>
    </head>

    <body>
        <div class="dashboard">

            <div class="top-header">
                <div class="user-info">
                    <h2>
                        Welcome, <?= htmlspecialchars($username) ?>
                        <?php if($is_member): ?><span class="member-badge">MEMBER</span><?php endif; ?>
                    </h2>
                </div>
                <div class="header-actions">
                    <a href="contactUs.php" class="btn-help">Help</a>
                    <?php if ($is_member): ?><a href="booking.php" class="btn-history">My Bookings</a><?php endif; ?>
                    <a href="logout.php" class="btn-logout"><?= $role === 'guest' ? 'Exit' : 'Logout' ?></a>
                </div>
            </div>

            <div class="search-box">
                <form method="GET" class="search-form">
                    <div class="form-group">
                        <label>From:</label>
                        <select name="origin" required>
                            <option value="">Select Origin</option>
                            <?php foreach($origins as $opt): ?>
                            <option value="<?= $opt ?>"
                                <?= (isset($_GET['origin']) && $_GET['origin'] == $opt) ? 'selected' : '' ?>>
                                <?= $opt ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>To:</label>
                        <select name="destination" required>
                            <option value="">Select Destination</option>
                            <?php foreach($destinations as $opt): ?>
                            <option value="<?= $opt ?>"
                                <?= (isset($_GET['destination']) && $_GET['destination'] == $opt) ? 'selected' : '' ?>>
                                <?= $opt ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Date:</label>
                        <input type="date" name="date" required value="<?= $_GET['date'] ?? '' ?>">
                    </div>

                    <button type="submit" name="search_flight" class="btn-search">Search Flights</button>
                </form>
            </div>

            <?php if ($search_performed): ?>

            <?php if (count($flights) > 0): ?>

            <div style="text-align:center;">
                <div class="controls-panel">
                    <div class="trip-toggle">
                        <label><input type="radio" name="trip_mode" id="mode_one" checked onclick="updateAllPrices()">
                            One Way</label>
                        <label><input type="radio" name="trip_mode" id="mode_round" onclick="updateAllPrices()"> Round
                            Trip</label>
                    </div>
                </div>
            </div>

            <table>
                <tr>
                    <th>Flight</th>
                    <th>Route</th>
                    <th>Departure</th>
                    <th>Arrival</th>
                    <th>Total Price</th>
                    <th>Action</th>
                </tr>
                <?php foreach ($flights as $flight): 
                        $raw_price = $flight['price'] ?? 150;
                        $base_price = $is_member ? ($raw_price * 0.90) : $raw_price;

                        $dep_ts = strtotime($flight['departure_time']);
                        $arr_ts = strtotime($flight['arrival_time']);
                        $ret_dep_ts = $dep_ts + (3 * 24 * 60 * 60); 
                        $ret_arr_ts = $arr_ts + (3 * 24 * 60 * 60);
                    ?>
                <tr>
                    <td>
                        <strong><?= htmlspecialchars($flight['flight_number']) ?></strong><br>
                        <small><?= htmlspecialchars($flight['airline']) ?></small>
                    </td>
                    <td>
                        <?= htmlspecialchars($flight['origin']) ?> &rarr;
                        <?= htmlspecialchars($flight['destination']) ?>
                    </td>
                    <td class="time-box">
                        <div><span class="date-main"><?= date('M d', $dep_ts) ?></span><?= date('H:i', $dep_ts) ?></div>
                        <div class="return-info">
                            <div class="return-label">Returning</div><span
                                class="date-main"><?= date('M d', $ret_dep_ts) ?></span><?= date('H:i', $ret_dep_ts) ?>
                        </div>
                    </td>
                    <td class="time-box">
                        <div><span class="date-main"><?= date('M d', $arr_ts) ?></span><?= date('H:i', $arr_ts) ?></div>
                        <div class="return-info">
                            <div class="return-label">Arriving</div><span
                                class="date-main"><?= date('M d', $ret_arr_ts) ?></span><?= date('H:i', $ret_arr_ts) ?>
                        </div>
                    </td>
                    <td>
                        <span class="price-tag dynamic-price" data-id="<?= $flight['flight_id'] ?>"
                            data-base="<?= $base_price ?>">
                            $<?= number_format($base_price, 2) ?>
                        </span>
                    </td>
                    <td>
                        <form method="POST" action="book_flight.php">
                            <input type="hidden" name="flight_id" value="<?= $flight['flight_id'] ?>">
                            <input type="hidden" id="input-price-<?= $flight['flight_id'] ?>" name="final_price"
                                value="<?= $base_price ?>">
                            <input type="hidden" id="input-type-<?= $flight['flight_id'] ?>" name="trip_type"
                                value="oneway">
                            <input type="number" name="num_passengers" value="1" min="1" max="10"
                                style="width:40px; text-align:center; margin-bottom:5px;">
                            <br><button class="btn-book" type="submit">Book</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>

            <?php else: ?>
            <div class="no-results">
                <h3>No flights found.</h3>
                <p>We couldn't find any flights from <strong><?= htmlspecialchars($_GET['origin']) ?></strong> to
                    <strong><?= htmlspecialchars($_GET['destination']) ?></strong> on
                    <strong><?= htmlspecialchars($_GET['date']) ?></strong>.</p>
            </div>
            <?php endif; ?>

            <?php else: ?>
            <div class="no-results" style="border: 2px dashed #ccc; border-radius:10px;">
                <h3>Ready to fly?</h3>
                <p>Select your origin, destination, and travel date above to find the best flights.</p>
            </div>
            <?php endif; ?>
        </div>
    </body>

</html>