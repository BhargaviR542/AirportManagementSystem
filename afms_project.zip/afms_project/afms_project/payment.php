<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

$flight_id = $_POST['flight_id'] ?? null;
$p_names = $_POST['p_names'] ?? [];
$p_passports = $_POST['p_passports'] ?? [];
$p_emails = $_POST['p_emails'] ?? [];
$selected_seats = $_POST['seats'] ?? [];
$user_id = $_SESSION['user_id'] ?? null;

if (count($selected_seats) != count($p_names)) {
    die("Error: You selected " . count($selected_seats) . " seats but have " . count($p_names) . " passengers. <a href='javascript:history.back()'>Go Back</a>");
}

if (isset($_POST['pay_now'])) {
    
    $final_names = $_POST['final_names'];
    $final_passports = $_POST['final_passports'];
    $final_emails = $_POST['final_emails'];
    $final_seats = $_POST['final_seats'];
    $booking_time = date("Y-m-d H:i:s");

    for ($i = 0; $i < count($final_names); $i++) {
        $ticket = strtoupper(bin2hex(random_bytes(4)));
        
        $sql = "INSERT INTO bookings 
                (user_id, flight_id, guest_name, guest_email, passport_number, ticket_number, payment_status, booking_time, seat_number) 
                VALUES (:uid, :fid, :name, :email, :pass, :ticket, 'Paid', :time, :seat)";
        
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':uid' => $user_id,
            ':fid' => $flight_id,
            ':name' => $final_names[$i],
            ':email' => $final_emails[$i],
            ':pass' => $final_passports[$i],
            ':ticket' => $ticket,
            ':time' => $booking_time,
            ':seat' => $final_seats[$i]
        ]);
    }

    echo "<div style='font-family:sans-serif; text-align:center; padding:50px;'>
            <h1 style='color:green;'>Thank you!!! Payment Successful!  </h1>
            <p> Your tickets have been booked.</p>
            <a href='passenger.php' style='padding:10px 20px; background:#007bff; color:white; text-decoration:none; border-radius:5px;'>Return to Dashboard</a>
          </div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Payment</title>
        <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        .summary {
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 15px;
            background: #28a745;
            color: white;
            border: none;
            font-size: 18px;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #218838;
        }

        /* NEW STYLE FOR CANCEL LINK */
        .cancel-link {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #dc3545;
            /* Red color */
            text-decoration: none;
            font-weight: bold;
        }

        .cancel-link:hover {
            text-decoration: underline;
        }
        </style>
    </head>

    <body>

        <div class="container">
            <h2>Payment Details</h2>

            <div class="summary">
                <strong>Total Passengers:</strong> <?= count($p_names) ?><br>
                <strong>Seats Selected:</strong> <?= implode(", ", $selected_seats) ?>
            </div>

            <form method="POST">
                <input type="hidden" name="flight_id" value="<?= $flight_id ?>">

                <?php foreach($p_names as $k => $v): ?>
                <input type="hidden" name="final_names[]" value="<?= htmlspecialchars($p_names[$k]) ?>">
                <input type="hidden" name="final_passports[]" value="<?= htmlspecialchars($p_passports[$k]) ?>">
                <input type="hidden" name="final_emails[]" value="<?= htmlspecialchars($p_emails[$k]) ?>">
                <input type="hidden" name="final_seats[]" value="<?= htmlspecialchars($selected_seats[$k]) ?>">
                <?php endforeach; ?>

                <label>Card Number</label>
                <input type="text" name="card_number" placeholder="Enter card number" maxlength="16" pattern="\d{16}"
                    required inputmode="numeric" oninput="this.value = this.value.replace(/[^0-9]/g, '')" onblur="
        if (this.value.length > 0 && this.value.length < 16) {
            alert('Enter valid card number');
            this.value = ''; 
            this.focus();    
        }
    ">
                <div style="display:flex; gap:10px;">
                    <div style="flex:1;">
                        <label>Expiry (MM/YY)</label>
                        <input type="text" name="expiry" placeholder="MM/YY" maxlength="5" required inputmode="numeric"
                            oninput="
                var v = this.value.replace(/\D/g, '');
                if (v.length > 2) {
                    this.value = v.slice(0, 2) + '/' + v.slice(2, 4);
                } else {
                    this.value = v;
                }
            " onblur="
                if (this.value.length === 5) {
                    var today = new Date();
                    var currentMonth = today.getMonth() + 1; 
                    var currentYear = parseInt(today.getFullYear().toString().substr(-2));

                    var parts = this.value.split('/');
                    var inputMonth = parseInt(parts[0]);
                    var inputYear = parseInt(parts[1]);

                    if (inputMonth < 1 || inputMonth > 12) {
                        alert('Invalid Month! Please enter valid details.');
                        this.value = '';
                        this.focus();
                    } 
                    else if (inputYear < currentYear || (inputYear === currentYear && inputMonth < currentMonth)) {
                        alert('Card Expired!!!');
                        this.value = '';
                        this.focus();
                    }
                }
            ">
                    </div>
                    <div style="flex:1;">
                        <label>CVV</label>
                        <input type="password" name="cvv" placeholder="CVV" maxlength="3" pattern="\d{3}" required
                            inputmode="numeric" oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                    </div>
                </div>

                <button type="submit" name="pay_now">Pay & Confirm</button>

                <a href="passenger.php" class="cancel-link">Cancel Booking</a>

            </form>
        </div>

    </body>

</html>