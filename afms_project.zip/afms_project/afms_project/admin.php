<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $id = $_POST['delete_id'];

    $checkStmt = $conn->prepare("SELECT COUNT(*) FROM bookings WHERE flight_id = ?");
    $checkStmt->execute([$id]);
    $bookingCount = $checkStmt->fetchColumn();

    if ($bookingCount > 0) {
        echo "<script>alert('Cannot delete this flight. There are $bookingCount passengers booked on it.'); window.location.href='admin.php';</script>";
        exit;
    } else {
        $stmt = $conn->prepare("DELETE FROM flights WHERE flight_id = ?");
        $stmt->execute([$id]);
        
        header("Location: admin.php");
        exit;
    }
}

$stmt = $conn->prepare("SELECT * FROM flights ORDER BY departure_time ASC");
$stmt->execute();
$flights = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Admin - Manage Flights</title>
        <link rel="stylesheet" href="assets/styles/admin-style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

        <style>
        /* --- [NEW] BUTTON GROUP STYLING --- */
        .button-group {
            display: flex;
            /* Enable Flexbox */
            justify-content: space-between;
            /* Pushes items to far left and right */
            width: 100%;
            /* Forces container to full width */
            margin-bottom: 20px;
            /* Space below buttons */
            align-items: center;
        }

        .button-group button {
            padding: 10px 20px;
            cursor: pointer;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .button-group button:hover {
            background-color: #0056b3;
        }

        table {

            width: 100%;

            border-collapse: collapse;

        }



        th,

        td {

            border: 1px solid #ccc;

            padding: 6px;

            text-align: center;

        }


        .actions a,
        .actions button {
            margin: 0 5px;
        }
        </style>
    </head>

    <body>
        <div class="container">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h2>Welcome <span style="color: blue; text-align: center;">
                        <?= htmlspecialchars(strtoupper($_SESSION['username'])) ?>
                    </span></h2>
                <a href="logout.php">Logout</a>
            </div>

            <a href="admin_contact.php"
                style="background-color:green; height: 30px; color: white; text-decoration: bold; text-align: center;">
                Help
                Requests</a>

            <div class="button-group">
                <a href="add_flight.php"><button>ADD FLIGHT</button></a>
                <a href="booking.php"><button>View Bookings</button></a>
            </div>

            <h3>Flights List</h3>
            <table>
                <tr>
                    <th>Flight No</th>
                    <th>Airline</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Departure</th>
                    <th>Arrival</th>
                    <th>Price ($)</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
                <?php foreach ($flights as $f): ?>
                <tr>
                    <td><?= htmlspecialchars($f['flight_number']) ?></td>
                    <td><?= htmlspecialchars($f['airline']) ?></td>
                    <td><?= htmlspecialchars($f['origin']) ?></td>
                    <td><?= htmlspecialchars($f['destination']) ?></td>
                    <td><?= htmlspecialchars($f['departure_time']) ?></td>
                    <td><?= htmlspecialchars($f['arrival_time']) ?></td>
                    <td><?= htmlspecialchars(number_format($f['price'], 2)) ?></td>
                    <td><?= htmlspecialchars($f['status']) ?></td>

                    <td class="actions">
                        <a href="edit_flight.php?id=<?= $f['flight_id'] ?>" title="Edit" style="color:blue;">
                            <i class="fa-solid fa-pen-to-square"></i> Edit
                        </a>

                        <form method="POST" style="display:inline;"
                            onsubmit="return confirm('Are you sure you want to delete this flight?');">
                            <input type="hidden" name="delete_id" value="<?= $f['flight_id'] ?>">
                            <button type="submit"
                                style="border:none; background:none; color:red; cursor:pointer; font-size:16px;"
                                title="Delete">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </body>

</html>