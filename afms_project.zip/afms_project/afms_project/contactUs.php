<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

// 1. CHECK USER ROLE
$role = $_SESSION['role'] ?? 'guest';
$is_guest = ($role === 'guest'); // True if guest, False if passenger/admin

// 2. PRE-FILL DATA (Only for Members)
$user_id = $_SESSION['user_id'] ?? null;
$name = '';
$email = '';

if (!$is_guest && $user_id) {
    $stmt = $conn->prepare("SELECT username, email FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $name = $user['username'];
        $email = $user['email'];
    }
}

// 3. HANDLE FORM SUBMISSION (Only allow if NOT guest)
$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_guest) {
    $p_name = $_POST['name'];
    $p_email = $_POST['email'];
    $p_subject = $_POST['subject'];
    $p_ref = $_POST['booking_ref'] ?? '';
    $p_message = $_POST['message'];

    $sql = "INSERT INTO help_requests (user_id, user_name, user_email, subject, booking_ref, message) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if ($stmt->execute([$user_id, $p_name, $p_email, $p_subject, $p_ref, $p_message])) {
        $msg = "<div class='alert success'>Request submitted! Our team will contact you shortly.</div>";
    } else {
        $msg = "<div class='alert error'>Something went wrong. Please try again.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Contact Support</title>
        <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        /* FORM STYLES */
        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
            color: #555;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            margin-top: 20px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }

        button:hover {
            background: #0056b3;
        }

        /* ALERTS */
        .alert {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 15px;
            text-decoration: none;
            color: #666;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        /* GUEST RESTRICTION BOX */
        .guest-box {
            text-align: center;
            background: #fff3cd;
            color: #856404;
            padding: 30px;
            border: 1px solid #ffeeba;
            border-radius: 8px;
        }

        .btn-login {
            display: inline-block;
            background: #28a745;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 15px;
            font-weight: bold;
        }
        </style>
    </head>

    <body>

        <div class="container">
            <h2>Airline Support Center</h2>

            <?php if ($is_guest): ?>

            <div class="guest-box">
                <h3>🔒 Member Access Only</h3>
                <p>Please log in to your account to fill out the support form and provide your details so we can help
                    you better.</p>
                <a href="login.php" class="btn-login">Login Now</a>
                <br><br>
                <a href="passenger.php" style="color:#856404; font-size:0.9em;">Back to Dashboard</a>
            </div>

            <?php else: ?>

            <?= $msg ?>

            <form method="POST">
                <label>Your Name:</label>
                <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

                <label>Email Address:</label>
                <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

                <label>What can we help you with?</label>
                <select name="subject" required onchange="toggleRefField(this.value)">
                    <option value="" disabled selected>Select an issue...</option>
                    <option value="Lost Baggage">Lost Baggage / Luggage Issue</option>
                    <option value="Change Flight">Request Flight Change / Reschedule</option>
                    <option value="Cancellation">Cancellation & Refund</option>
                    <option value="Special Assistance">Special Assistance</option>
                    <option value="Other">Other Inquiry</option>
                </select>

                <label>Booking Reference / Ticket # (Optional):</label>
                <input type="text" name="booking_ref" placeholder="e.g. #15" id="ref-field">

                <label>Message / Details:</label>
                <textarea name="message" rows="5" placeholder="Please describe your issue..." required></textarea>

                <button type="submit">Submit Request</button>
            </form>

            <a href="passenger.php" class="back-link">&larr; Back to Dashboard</a>

            <?php endif; ?>
        </div>

        <script>
        function toggleRefField(val) {
            var refInput = document.getElementById('ref-field');
            if (val === 'Change Flight' || val === 'Cancellation' || val === 'Lost Baggage') {
                refInput.style.borderColor = "#007bff";
                refInput.placeholder = "Required for this request";
            } else {
                refInput.style.borderColor = "#ccc";
                refInput.placeholder = "e.g. #15";
            }
        }
        </script>

    </body>

</html>