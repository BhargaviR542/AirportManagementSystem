<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

if (!isset($_POST['flight_id'])) { header("Location: passenger.php"); exit; }

$flight_id = $_POST['flight_id'];

// 1. RECEIVE DATA
$trip_type = $_POST['trip_type'];
$final_price_per_person = $_POST['final_price'];
$p_names = $_POST['passenger_name'];
$p_passports = $_POST['passport_number'];
$p_emails = $_POST['passenger_email'];
$count = count($p_names);

// 2. FETCH OCCUPIED SEATS
$stmt = $conn->prepare("SELECT seat_number FROM bookings WHERE flight_id = ?");
$stmt->execute([$flight_id]);
$occupied = $stmt->fetchAll(PDO::FETCH_COLUMN);

// 3. CALCULATE GRAND TOTAL
$grand_total = $final_price_per_person * $count;
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Select Seats</title>
        <style>
        body {
            font-family: sans-serif;
            background: #eee;
            padding: 20px;
            text-align: center;
        }

        .plane {
            display: inline-block;
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        /* HIDE CHECKBOX */
        input[type=checkbox] {
            display: none;
        }

        /* SEAT STYLE */
        .seat {
            width: 40px;
            height: 40px;
            background: #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        /* SELECTED STATE */
        input[type=checkbox]:checked+.seat {
            background: #28a745;
            color: white;
            transform: scale(1.1);
        }

        /* DISABLED STATE */
        input[type=checkbox]:disabled+.seat {
            background: #dc3545;
            color: white;
            cursor: not-allowed;
            opacity: 0.5;
        }

        .info-box {
            background: white;
            display: inline-block;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        </style>

        <script>
        function checkLimit(checkbox) {
            var limit = <?= $count ?>;
            var checked = document.querySelectorAll('input[type=checkbox]:checked').length;

            document.getElementById('count-display').innerText = checked + " / " + limit;

            if (checked > limit) {
                alert("You only need to select " + limit + " seats.");
                checkbox.checked = false;
                document.getElementById('count-display').innerText = (checked - 1) + " / " + limit;
            }
        }
        </script>
    </head>

    <body>

        <div class="info-box">
            <h3>Select <?= $count ?> Seat(s)</h3>
            <p>Type: <strong><?= htmlspecialchars($trip_type) ?></strong></p>
            <p>Total to Pay: <strong
                    style="color:green; font-size:1.2em;">$<?= number_format($grand_total, 2) ?></strong></p>
            <p>Selected: <span id="count-display" style="font-weight:bold;">0 / <?= $count ?></span></p>
        </div>

        <form action="payment.php" method="POST"> <input type="hidden" name="flight_id" value="<?= $flight_id ?>">
            <input type="hidden" name="grand_total" value="<?= $grand_total ?>">

            <?php foreach($p_names as $k => $val): ?>
            <input type="hidden" name="p_names[]" value="<?= htmlspecialchars($p_names[$k]) ?>">
            <input type="hidden" name="p_passports[]" value="<?= htmlspecialchars($p_passports[$k]) ?>">
            <input type="hidden" name="p_emails[]" value="<?= htmlspecialchars($p_emails[$k]) ?>">
            <?php endforeach; ?>

            <div class="plane">
                <div style="color:#aaa; font-weight:bold; margin-bottom:10px;">FRONT</div>
                <?php for($r=1; $r<=6; $r++): ?>
                <div class="row">
                    <?php foreach(['A','B'] as $c): $seat = $r.$c; $taken = in_array($seat, $occupied); ?>
                    <label>
                        <input type="checkbox" name="seats[]" value="<?= $seat ?>" <?= $taken ? 'disabled' : '' ?>
                            onclick="checkLimit(this)">
                        <div class="seat"><?= $seat ?></div>
                    </label>
                    <?php endforeach; ?>

                    <div style="width:20px;"></div>
                    <?php foreach(['C','D'] as $c): $seat = $r.$c; $taken = in_array($seat, $occupied); ?>
                    <label>
                        <input type="checkbox" name="seats[]" value="<?= $seat ?>" <?= $taken ? 'disabled' : '' ?>
                            onclick="checkLimit(this)">
                        <div class="seat"><?= $seat ?></div>
                    </label>
                    <?php endforeach; ?>
                </div>
                <?php endfor; ?>
            </div>

            <br>
            <button type="submit"
                style="padding:15px 30px; background:#007bff; color:white; border:none; border-radius:5px; cursor:pointer;">
                Proceed to Payment
            </button>

        </form>

    </body>

</html>