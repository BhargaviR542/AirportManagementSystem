<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

// Only allow admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Handle saving remarks
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_id']) && isset($_POST['remarks'])) {
    $reqId = (int)$_POST['request_id'];
    $remarks = trim($_POST['remarks']);

    $stmt = $conn->prepare("UPDATE help_requests SET remarks = :remarks WHERE request_id = :id");
    $stmt->execute([
        ':remarks' => $remarks,
        ':id' => $reqId
    ]);

    header("Location: admin_contact.php");
    exit;
}

// Handle status toggle
if (isset($_GET['toggle_status']) && isset($_GET['request_id'])) {
    $reqId = (int)$_GET['request_id'];

    $stmt = $conn->prepare("SELECT status FROM help_requests WHERE request_id = :id");
    $stmt->execute([':id' => $reqId]);
    $current = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($current) {
        $newStatus = ($current['status'] === 'Pending') ? 'Solved' : 'Pending';
        $stmt = $conn->prepare("UPDATE help_requests SET status = :status WHERE request_id = :id");
        $stmt->execute([':status' => $newStatus, ':id' => $reqId]);
    }

    header("Location: admin_contact.php");
    exit;
}

// Fetch all help requests
$stmt = $conn->prepare("
    SELECT h.request_id, u.username, h.request_type, h.subject, h.message, 
           h.status, h.created_at, COALESCE(h.remarks, '') AS remarks
    FROM help_requests h
    JOIN users u ON h.user_id = u.user_id
    ORDER BY h.created_at DESC
");
$stmt->execute();
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>Admin - Help Requests</title>
        <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th,
        td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f0f0f0;
        }

        button {
            cursor: pointer;
            padding: 5px 10px;
            margin-top: 2px;
        }

        a {
            text-decoration: none;
            color: #007bff;
        }

        a:hover {
            text-decoration: underline;
        }

        .remarks-text {
            display: inline-block;
        }

        .remarks-input {
            display: none;
            width: 100%;
        }
        </style>
        <script>
        function editRemarks(id) {
            document.getElementById('text-' + id).style.display = 'none';
            document.getElementById('input-' + id).style.display = 'inline-block';
            document.getElementById('edit-btn-' + id).style.display = 'none';
            document.getElementById('save-btn-' + id).style.display = 'inline-block';
        }

        function cancelEdit(id) {
            document.getElementById('text-' + id).style.display = 'inline-block';
            document.getElementById('input-' + id).style.display = 'none';
            document.getElementById('edit-btn-' + id).style.display = 'inline-block';
            document.getElementById('save-btn-' + id).style.display = 'none';
        }
        </script>
    </head>

    <body>
        <h2>Help Requests</h2>
        <a href="admin.php">← Back to Admin Dashboard</a>

        <?php if(empty($requests)): ?>
        <p>No requests submitted yet.</p>
        <?php else: ?>
        <table>
            <tr>
                <th>Username</th>
                <th>Type</th>
                <th>Subject</th>
                <th>Message</th>
                <th>Status</th>
                <th>Submitted At</th>
                <th>Remarks</th>
                <th>Action</th>
            </tr>
            <?php foreach($requests as $r): ?>
            <tr>
                <td><?= htmlspecialchars($r['username']) ?></td>
                <td><?= htmlspecialchars($r['request_type']) ?></td>
                <td><?= htmlspecialchars($r['subject']) ?></td>
                <td><?= htmlspecialchars($r['message']) ?></td>
                <td><?= htmlspecialchars($r['status']) ?></td>
                <td><?= htmlspecialchars($r['created_at']) ?></td>
                <td>
                    <form method="POST" style="margin:0;" id="form-<?= $r['request_id'] ?>">
                        <input type="hidden" name="request_id" value="<?= $r['request_id'] ?>">
                        <span class="remarks-text"
                            id="text-<?= $r['request_id'] ?>"><?= htmlspecialchars($r['remarks']) ?: '[No Remarks]' ?></span>
                        <input type="text" name="remarks" class="remarks-input" id="input-<?= $r['request_id'] ?>"
                            value="<?= htmlspecialchars($r['remarks']) ?>">
                        <button type="submit" style="display:none;" id="save-btn-<?= $r['request_id'] ?>">Save</button>
                        <button type="button" id="edit-btn-<?= $r['request_id'] ?>"
                            onclick="editRemarks(<?= $r['request_id'] ?>)">Edit</button>
                        <button type="button" style="display:none;"
                            onclick="cancelEdit(<?= $r['request_id'] ?>)">Cancel</button>
                    </form>
                </td>
                <td>
                    <a href="admin_contact.php?toggle_status=1&request_id=<?= $r['request_id'] ?>">
                        <?= $r['status'] === 'Pending' ? 'Mark Solved' : '' ?>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </body>

</html>