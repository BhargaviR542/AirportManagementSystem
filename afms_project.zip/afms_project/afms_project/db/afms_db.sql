-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2025 at 11:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `afms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `flight_id` int(11) NOT NULL,
  `guest_name` varchar(255) DEFAULT NULL,
  `guest_email` varchar(255) DEFAULT NULL,
  `passport_number` varchar(50) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `booking_time` datetime DEFAULT current_timestamp(),
  `payment_status` varchar(50) NOT NULL DEFAULT 'Pending',
  `ticket_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `flight_id`, `guest_name`, `guest_email`, `passport_number`, `user_id`, `seat_number`, `booking_time`, `payment_status`, `ticket_number`) VALUES
(11, 13, 'John Doe', 'john@gmail.com', '789654446777878', NULL, '2A', '2025-12-01 03:42:20', 'Paid', '98B84BC8'),
(12, 13, 'Lucy', 'lucy@gmail.com', '67855689', NULL, '3A', '2025-12-01 03:53:18', 'Paid', '5B2D2CB5'),
(13, 13, 'Cameron', 'cameron@gmail.com', '6789965556', NULL, '3B', '2025-12-01 03:53:18', 'Paid', '9523DE5A'),
(14, 13, 'ken P', 'ken@gmail.com', '1234566777', NULL, '3C', '2025-12-01 03:53:18', 'Paid', '61775C16'),
(15, 13, 'En peter', 'peter@gmail.com', '45674324555', NULL, '3D', '2025-12-01 03:53:18', 'Paid', 'D6C4953A'),
(16, 13, 'Benton', 'benton@gmail.com', '56784333566', NULL, '4A', '2025-12-01 04:02:28', 'Paid', 'F55B3503'),
(17, 13, 'Renford Ler', 'renford34@gmail.com', 'B45673156', NULL, '4D', '2025-12-01 04:17:34', 'Paid', 'DCD713BB'),
(19, 13, 'bdtg', 'dfgg@gmail.com', 'ffdgf', NULL, '1D', '2025-12-01 22:25:41', 'Paid', 'D95A1976'),
(20, 13, 'ffdgf', 'ftdhg@gmail.com', 'ccgg', NULL, '5C', '2025-12-01 22:25:41', 'Paid', '2971C942'),
(21, 13, 'bob', 'bob@gmail.com', 'V5678903', NULL, '1B', '2025-12-01 23:02:38', 'Paid', '1FDC75A6');

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `flight_id` int(11) NOT NULL,
  `flight_number` varchar(20) NOT NULL,
  `airline` varchar(100) DEFAULT NULL,
  `origin` varchar(50) DEFAULT NULL,
  `destination` varchar(50) DEFAULT NULL,
  `departure_time` datetime DEFAULT NULL,
  `arrival_time` datetime DEFAULT NULL,
  `status` enum('Scheduled','Delayed','Departed','Cancelled') DEFAULT 'Scheduled',
  `price` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`flight_id`, `flight_number`, `airline`, `origin`, `destination`, `departure_time`, `arrival_time`, `status`, `price`) VALUES
(3, 'UA339', 'United Airlines', 'Chicago', 'Toronto', '2025-10-27 12:45:00', '2025-10-27 14:30:00', 'Scheduled', 123.00),
(10, 'UA335', 'American Airlines', 'Forida', 'Kansas', '2025-11-19 16:21:00', '2025-11-19 18:19:00', 'Scheduled', 340.00),
(11, 'A345G', 'United Airlines', 'Forida', 'Kansas', '2025-11-27 14:13:00', '2025-11-28 16:13:00', 'Delayed', 234.00),
(12, 'S234R', 'Qatar Airways', 'South Carolina', 'Michigan', '2025-11-26 14:15:00', '2025-11-30 14:15:00', 'Scheduled', 127.00),
(13, 'FR345', 'skyline Airways', 'Denmark', 'saudi Arabia', '2025-12-03 12:15:00', '2025-11-11 02:17:00', 'Scheduled', 765.00),
(14, 'AZ123', 'Qatar Airways', 'Agartala', 'Delhi', '2025-12-27 12:17:00', '2025-12-27 18:18:00', 'Scheduled', 678.00),
(15, 'A765R', 'Australian Airlines', 'London, UK', 'Australia', '2025-12-18 12:19:00', '2025-12-25 12:20:00', 'Scheduled', 567.00),
(16, 'RD1123T', 'Global Wings', 'Bangalore, India', 'Delhi, India', '2025-12-10 12:29:00', '2025-12-10 18:35:00', 'Scheduled', 231.00),
(17, 'AD1234', 'Global Wings', 'New York, United states', 'Buffalo, United states', '2025-12-25 00:32:00', '2025-12-26 13:33:00', 'Scheduled', 345.00),
(18, 'WE234', 'Skyline Airways', 'Acapulco, Mexico', 'Mexico, Mexico', '2025-12-11 12:34:00', '2025-12-12 12:34:00', 'Scheduled', 765.00);

-- --------------------------------------------------------

--
-- Table structure for table `help_requests`
--

CREATE TABLE `help_requests` (
  `request_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `request_type` varchar(50) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `remarks` text DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `help_requests`
--

INSERT INTO `help_requests` (`request_id`, `user_id`, `request_type`, `subject`, `message`, `status`, `created_at`, `remarks`) VALUES
(1, 2, 'Lost Baggage', 'Flight number - U123E I lost baggage', '2345 is the number written on bag while travelling from chicago to Florida', 'Solved', '2025-11-21 16:51:36', 'Luggage is sent to your mentionedaddress');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('admin','passenger') DEFAULT 'passenger',
  `loyalty_points` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `full_name`, `email`, `role`, `loyalty_points`) VALUES
(1, 'admin', '$2y$10$A8vIBH1LVni8gmAz9rPPFuVmHDmvxT05uaS5ugj4I5YhxdtvHpctK', 'Admin User', 'admin@afms.com', 'admin', NULL),
(2, 'bhargavi', '$2y$10$txeyfWjAnb9MzVTFp810g.0ebcg4/fxoXbprYKbWoFcG9PxVHoBsC', 'Bhargavi R', 'bhargavi@gmail.com', 'passenger', 10),
(3, 'chandana', '$2y$10$tEwgejAktoToq.aK.ZTBqeBWO73bHYKIi2NQDXgl3WzmQkgPMiaRy', 'Chandana B', 'chandana@gmail.com', 'passenger', 0),
(5, 'achyuth', '$2y$10$XiFw9cX/SAlCiHfe3OiC5uMh0R8hWtIvJ64YhuJYe0vq2SIMpf7a2', 'Achyuth R', 'achyuth@gmail.com', 'passenger', 30),
(6, 'krishna', '$2y$10$IYHiAk6DRccRBi7RUEO2W.8bh0uJx4nf1u3XRR6m9KHR6uJMzN22O', 'Krishna R', 'krishna@gmail.com', 'passenger', 0),
(7, 'bhargavi67', '$2y$10$R7et9oPkRPRTbumDQuK1Ve8mBk0US/.J732mQ6K4hRG2Elm8G1rnG', 'Bhargavi', 'bhargavi.ravipati@gmail.com', 'passenger', 0),
(8, 'Ram123', '$2y$10$ivNxoKbnSziqVS9RfgNX0ubQhIUjJj5a6nvJB54nxxgyfQLLrdl8O', 'Ram', 'Ram@gmail.com', 'passenger', 0),
(9, 'Bhargavi678', '$2y$10$wHmfucEIikQ1s/rYkPTf4OurfhQwNyJRA3afsWsh1UnjKYyF2yZwS', 'Bhargavi Ravipati', 'bhargaviravipati5@gmail.com', 'passenger', 0),
(10, 'Balu78', '$2y$10$qrrwOaM0bvLQwt8C9XZSPuFlM6ihMIsMhSsVssHd1qQUqy.mUWgni', 'Balu', 'balu.r@gmail.com', 'passenger', 0),
(11, 'chandu345', '$2y$10$GGJDELMAPhP2VxPQNPgnueSHsaN44p9Rk98IAyeKzNNhTib4ZGuGS', 'Chandu K', 'chandu@gmail.com', 'passenger', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_cookies`
--

CREATE TABLE `user_cookies` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cookie_name` varchar(255) NOT NULL,
  `cookie_value` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_cookies`
--

INSERT INTO `user_cookies` (`id`, `user_id`, `cookie_name`, `cookie_value`, `created_at`) VALUES
(1, 1, 'visitor_id', '76649ee4c3cdd12dffb2084f246253b2', '2025-11-21 01:42:22'),
(2, 1, 'visitor_id', '026c8ff553e4dce89df8c30942e06479', '2025-11-21 01:46:17'),
(3, 1, 'visitor_id', '64ee1985cf1f5e0b538a911b81e8d6df', '2025-11-28 23:04:19'),
(4, 9, 'visitor_id', '10c28bb92b271a3583f9c48b612845b8', '2025-11-29 14:33:55'),
(5, 10, 'visitor_id', 'a5a137b2155821eb0a5c1b1effd3bcf2', '2025-11-29 15:43:53'),
(6, 11, 'visitor_id', 'f50971b21d84e647f95ba9aacdcd5f3d', '2025-11-29 15:54:12');

-- --------------------------------------------------------

--
-- Table structure for table `user_visits`
--

CREATE TABLE `user_visits` (
  `visit_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `visit_time` datetime DEFAULT current_timestamp(),
  `user_agent` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_visits`
--

INSERT INTO `user_visits` (`visit_id`, `user_id`, `visit_time`, `user_agent`) VALUES
(1, 2, '2025-10-21 13:09:43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'),
(2, 3, '2025-10-21 13:09:43', 'Chrome/141.0.0.0 Safari/537.36'),
(3, 1, '2025-10-21 13:09:43', 'Edge/110.0 Windows 11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD UNIQUE KEY `ticket_number` (`ticket_number`),
  ADD KEY `flight_id` (`flight_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`flight_id`),
  ADD UNIQUE KEY `flight_number` (`flight_number`);

--
-- Indexes for table `help_requests`
--
ALTER TABLE `help_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `user_cookies`
--
ALTER TABLE `user_cookies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_visits`
--
ALTER TABLE `user_visits`
  ADD PRIMARY KEY (`visit_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `flights`
--
ALTER TABLE `flights`
  MODIFY `flight_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `help_requests`
--
ALTER TABLE `help_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_cookies`
--
ALTER TABLE `user_cookies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_visits`
--
ALTER TABLE `user_visits`
  MODIFY `visit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`flight_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `help_requests`
--
ALTER TABLE `help_requests`
  ADD CONSTRAINT `help_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_cookies`
--
ALTER TABLE `user_cookies`
  ADD CONSTRAINT `user_cookies_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_visits`
--
ALTER TABLE `user_visits`
  ADD CONSTRAINT `user_visits_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
