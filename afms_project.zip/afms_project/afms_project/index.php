<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/includes/connect.php';

require_once __DIR__ . '/app/models/UserModel.php';
require_once __DIR__ . '/app/models/PassengerModel.php';

require_once __DIR__ . '/app/controllers/LoginController.php';
require_once __DIR__ . '/app/controllers/PassengerController.php';

$routes = [
    'login'        => ['LoginController', 'handleLogin', 'app/views/login.php'],
    'register'     => ['PassengerController', 'handleRegister', 'app/views/register.php'],
    'admin'        => ['PageController', 'show', 'admin.php'],
    'passenger'    => ['PageController', 'show', 'passenger.php'],
    'add_flight'   => ['PageController', 'show', 'add_flight.php'],
    'edit_flight'  => ['PageController', 'show', 'edit_flight.php'],
    'delete_flight'=> ['PageController', 'show', 'delete_flight.php'],
    'book_flight'  => ['PageController', 'show', 'book_flight.php'],
    'booking'      => ['PageController', 'show', 'booking.php'],
    'edit_booking' => ['PageController', 'show', 'edit_booking.php'],
    'cancel_booking'=> ['PageController', 'show', 'cancel_booking.php'],
    'contact'      => ['PageController', 'show', 'contactUs.php'],
    'admin_contact'=> ['PageController', 'show', 'admin_contact.php'],
    'logout'       => ['PageController', 'show', 'logout.php'],
    'select_seats' => ['PageController', 'show', 'select_seats.php'],
    'payment'      => ['PageController', 'show', 'payment.php'],
];

$page = isset($_GET['page']) ? preg_replace('/[^a-z0-9_]/i', '', $_GET['page']) : 'login';

if ($page === '' || !array_key_exists($page, $routes)) {
    http_response_code(404);
    echo "<h1>404 Not Found</h1><p>Requested page not found.</p>";
    exit;
}

list($controllerName, $method, $viewFile) = $routes[$page];

if ($controllerName === 'LoginController') {
    $controller = new LoginController(new UserModel($conn));
    $controller->$method();
} elseif ($controllerName === 'PassengerController') {
    if (isset($_GET['action']) && $_GET['action'] === 'ajaxCheck') {
        $controller = new PassengerController(new PassengerModel($conn));
        $controller->handleAjaxCheck();
    } else {
        $controller = new PassengerController(new PassengerModel($conn));
        $controller->$method();
    }
}

$viewPath = __DIR__ . '/' . $viewFile;
if (file_exists($viewPath)) {
    include $viewPath;
} else {
    http_response_code(500);
    echo "<h1>500 Internal Server Error</h1><p>View file not found: " . htmlspecialchars($viewFile) . "</p>";
}

?>