<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

// 1. Must be logged in
if (!isset($_SESSION['role'])) {
    header("Location: login.php"); exit;
}

if (isset($_GET['id'])) {
    $booking_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    $role = $_SESSION['role'];

    // 2. CHECK PERMISSIONS & TIME
    if ($role === 'admin') {
        // Admin can delete anything instantly
        $stmt = $conn->prepare("DELETE FROM bookings WHERE booking_id = ?");
        $stmt->execute([$booking_id]);
    } 
    else {
        // Passenger: Must Check Ownership AND Time
        
        // A. Get Flight Time for this booking
        $stmt = $conn->prepare("
            SELECT f.departure_time 
            FROM bookings b 
            JOIN flights f ON b.flight_id = f.flight_id 
            WHERE b.booking_id = ? AND b.user_id = ?
        ");
        $stmt->execute([$booking_id, $user_id]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($booking) {
            // B. Calculate Time
            $flight_time = strtotime($booking['departure_time']);
            $current_time = time();
            $hours_diff = ($flight_time - $current_time) / 3600;

            if ($hours_diff > 24) {
                // Time is OK -> Delete
                $del = $conn->prepare("DELETE FROM bookings WHERE booking_id = ?");
                $del->execute([$booking_id]);
            } else {
                echo "<script>alert('Error: You cannot cancel within 24 hours of flight.'); window.location='booking.php';</script>";
                exit;
            }
        } else {
            // Booking doesn't belong to this user
            echo "<script>alert('Access Denied.'); window.location='booking.php';</script>";
            exit;
        }
    }

    // Success redirect
    header("Location: booking.php?msg=cancelled");
    exit;
} else {
    header("Location: booking.php");
}
?>