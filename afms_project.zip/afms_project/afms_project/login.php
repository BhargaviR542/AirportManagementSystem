<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/connect.php';

class UserModel {
    private $db;

    public function __construct($database) {
        $this->db = $database;
    }

    // Fetch user by username and role
    public function getUser($username, $role) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username AND role = :role");
        $stmt->execute([':username' => $username, ':role' => $role]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Set visitor cookie and store in DB
    public function setCookieInDatabase($userId, $name, $value, $expire = 86400) {
        setcookie($name, $value, time() + $expire, "/");
        $stmt = $this->db->prepare(
            "INSERT INTO user_cookies (user_id, cookie_name, cookie_value)
             VALUES (:user_id, :cookie_name, :cookie_value)
             ON DUPLICATE KEY UPDATE cookie_value = :cookie_value"
        );
        $stmt->execute([
            ':user_id' => $userId,
            ':cookie_name' => $name,
            ':cookie_value' => $value
        ]);
    }
}

class LoginController {
    private $userModel;

    public function __construct($userModel) {
        $this->userModel = $userModel;
    }

    public function handleLogin() {
        
        // --- NEW: HANDLE GUEST LOGIN ---
        if (isset($_GET['action']) && $_GET['action'] === 'guest') {
            // Set minimal session data required to pass security checks
            $_SESSION['role'] = 'guest';
            $_SESSION['username'] = 'Guest';
            $_SESSION['status'] = 'Logged_in';
            
            // Redirect to dashboard
            header("Location: passenger.php");
            exit;
        }
        // -------------------------------

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim(filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING));
            $password = trim(filter_input(INPUT_POST, 'password', FILTER_UNSAFE_RAW));
            $role     = trim(filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING));

            // Save old input to repopulate form
            $_SESSION['old'] = ['username'=>$username, 'role'=>$role];

            if (empty($username) || empty($password) || empty($role)) {
                $_SESSION['error'] = "Please fill all fields and select a role.";
                header("Location: index.php?page=login"); exit;
            }

            $user = $this->userModel->getUser($username, $role);

            if (!$user || !password_verify($password, $user['password'])) {
                $_SESSION['error'] = "Invalid username or password.";
                header("Location: index.php?page=login"); exit;
            }

            // Store user info in session
            $_SESSION['user_id']  = $user['user_id']; 
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];
            $_SESSION['full_name'] = $user['full_name']; 
            $_SESSION['status']   = 'Logged_in';
            $_SESSION['success']  = "Welcome, {$user['full_name']}!";

            if (!isset($_COOKIE['visitor_id'])) {
                $visitorId = bin2hex(random_bytes(16));
                $this->userModel->setCookieInDatabase($user['user_id'], 'visitor_id', $visitorId, 60*60*24);
            }

            // Page view counter
            $pageViews = isset($_COOKIE['page_view_count']) ? (int)$_COOKIE['page_view_count'] + 1 : 1;
            setcookie('page_view_count', $pageViews, time()+60*60*24*30, "/");

            // Redirect based on role
            if ($role === 'admin') header("Location: index.php?page=admin");
            else header("Location: index.php?page=passenger");
            exit;
        }
    }
}

$userModel  = new UserModel($conn);
$controller = new LoginController($userModel);
$controller->handleLogin();
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <title>AFMS Login</title>
        <link rel="stylesheet" href="assets/styles/style.css">
    </head>

    <body>
        <div class="login-container">
            <h2>Airport Flight Management System</h2>

            <?php if (!empty($_SESSION['error'])): ?>
            <p class="error"><?= htmlspecialchars($_SESSION['error']) ?></p>
            <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <?php if (!empty($_SESSION['success'])): ?>
            <p class="success"><?= htmlspecialchars($_SESSION['success']) ?></p>
            <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <form method="POST" novalidate>
                <div class="form-row">
                    <label>Role:</label>
                    <select name="role" required>
                        <option value="">-- Select Role --</option>
                        <option value="admin"
                            <?= (isset($_SESSION['old']['role']) && $_SESSION['old']['role']=='admin') ? 'selected' : '' ?>>
                            Admin</option>
                        <option value="passenger"
                            <?= (isset($_SESSION['old']['role']) && $_SESSION['old']['role']=='passenger') ? 'selected' : '' ?>>
                            Passenger</option>
                    </select>
                </div>

                <div class="form-row">
                    <label>Username:</label>
                    <input type="text" name="username" placeholder="Enter username" required
                        value="<?= isset($_SESSION['old']['username']) ? htmlspecialchars($_SESSION['old']['username']) : '' ?>">
                </div>

                <div class="form-row">
                    <label>Password:</label>
                    <input type="password" name="password" placeholder="Enter password" required>
                </div>

                <button type="submit">Login</button>
                <p class="note">Don't have an account? <a href="index.php?page=register">Register here</a></p>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="index.php?page=login&action=guest" class="guest-link">Continue as Guest</a>
                </div>
            </form>

            <?php unset($_SESSION['old']); ?>
        </div>
    </body>

</html>